# Step 1 — Environment Variables

## What This Does

Adds Anthropic API credentials and provider routing config to the VPS. No code changes — just env vars that the module will read.

## Add to VPS `.env`

SSH into Hostinger VPS. Add these to your existing `.env` file (alongside the Grok/Stripe keys):

```bash
# --- AI Provider: Anthropic (Claude) ---
ANTHROPIC_API_KEY=sk-ant-your-key-here
CLAUDE_MODEL=claude-sonnet-4-6

# --- AI Provider: Routing ---
AI_PROVIDER_DEFAULT_PRIMARY=grok
AI_PROVIDER_DEFAULT_FALLBACK=claude
AI_PROVIDER_PAGE_BUILDER_PRIMARY=grok
```

## What Each Variable Does

- `ANTHROPIC_API_KEY` — Auth for the Anthropic Messages API. Get this from console.anthropic.com.
- `CLAUDE_MODEL` — Model string. Defaults to `claude-sonnet-4-6` in code if unset. Useful for testing a different model without touching PHP.
- `AI_PROVIDER_DEFAULT_PRIMARY` — Which provider handles all tasks by default.
- `AI_PROVIDER_DEFAULT_FALLBACK` — Which provider takes over when the primary fails.
- `AI_PROVIDER_PAGE_BUILDER_PRIMARY` — Per-task override for page builder. Set to `claude` later to promote it. No redeploy needed.

## Verify

```bash
source .env
echo $ANTHROPIC_API_KEY   # should print your key
echo $CLAUDE_MODEL         # should print claude-sonnet-4-6
```

Make sure your web server process (Apache/Nginx + PHP-FPM) can read these. If you're using `vlucas/phpdotenv` or Drupal's settings.php to load env vars, confirm they're picked up there.

## Done

Move to `02_MODULE_SCAFFOLD.md`.
