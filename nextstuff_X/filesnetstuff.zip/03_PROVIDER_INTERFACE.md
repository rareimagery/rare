# Step 3 — Provider Interface + Response DTO

## What This Does

Creates the contract that every AI provider must implement, and the normalized response object that the rest of the system works with. These two files are the foundation — everything else depends on them.

## AiProviderInterface.php

**File:** `src/Provider/AiProviderInterface.php`

```php
<?php

namespace Drupal\ai_provider\Provider;

use Drupal\ai_provider\Model\AiResponse;

/**
 * Contract for AI provider implementations.
 *
 * Every provider (Grok, Claude, future additions) implements this.
 * The AiProviderManager only interacts through this interface.
 */
interface AiProviderInterface {

  /**
   * Unique provider key.
   *
   * @return string
   *   e.g., 'grok', 'claude'.
   */
  public function getKey(): string;

  /**
   * Whether this provider is configured and reachable.
   *
   * Checks that the API key is set. Does NOT make a network call.
   *
   * @return bool
   */
  public function isAvailable(): bool;

  /**
   * Execute an AI generation request.
   *
   * @param string $task_type
   *   One of: 'theme_generation', 'page_builder', 'profile_import',
   *   'content_generation'.
   * @param array $prompt_data
   *   Task-specific payload. Always contains:
   *     - 'user_input' (string): The creator's prompt/request.
   *   May also contain:
   *     - 'subculture' (string): Active theme subculture key.
   *     - 'existing_theme' (string): Current theme JSON config.
   *     - 'profile_data' (array): X profile data (Grok only).
   * @param array $options
   *   Optional overrides:
   *     - 'temperature' (float): Default 1.
   *     - 'max_tokens' (int): Default provider-specific.
   *
   * @return \Drupal\ai_provider\Model\AiResponse
   *
   * @throws \Drupal\ai_provider\Exception\AiGenerationException
   */
  public function generate(string $task_type, array $prompt_data, array $options = []): AiResponse;

}
```

## AiResponse.php

**File:** `src/Model/AiResponse.php`

```php
<?php

namespace Drupal\ai_provider\Model;

/**
 * Normalized AI response.
 *
 * Returned by every provider regardless of their native response format.
 * The controller serializes this to JSON for the Next.js frontend.
 */
class AiResponse {

  public function __construct(
    public readonly string $provider,
    public readonly string $task_type,
    public readonly string $raw_text,
    public readonly ?array $structured_data = NULL,
    public readonly string $model = '',
    public readonly array $usage = [],
  ) {}

  /**
   * Serialize for JSON:API response.
   *
   * @return array
   */
  public function toArray(): array {
    return [
      'provider' => $this->provider,
      'task_type' => $this->task_type,
      'data' => $this->structured_data ?? $this->raw_text,
      'meta' => [
        'model' => $this->model,
        'usage' => $this->usage,
      ],
    ];
  }

}
```

## Exception Classes

**File:** `src/Exception/AiGenerationException.php`

```php
<?php

namespace Drupal\ai_provider\Exception;

/**
 * Thrown when an AI provider fails to generate a response.
 */
class AiGenerationException extends \RuntimeException {}
```

**File:** `src/Exception/ProviderUnavailableException.php`

```php
<?php

namespace Drupal\ai_provider\Exception;

/**
 * Thrown when a provider is not configured or reachable.
 */
class ProviderUnavailableException extends \RuntimeException {

  public function __construct(string $provider_key, int $code = 0, ?\Throwable $previous = NULL) {
    parent::__construct("AI provider '{$provider_key}' is unavailable.", $code, $previous);
  }

}
```

## Verify

Four files created:

- `src/Provider/AiProviderInterface.php`
- `src/Model/AiResponse.php`
- `src/Exception/AiGenerationException.php`
- `src/Exception/ProviderUnavailableException.php`

Quick syntax check:

```bash
php -l modules/custom/ai_provider/src/Provider/AiProviderInterface.php
php -l modules/custom/ai_provider/src/Model/AiResponse.php
php -l modules/custom/ai_provider/src/Exception/AiGenerationException.php
php -l modules/custom/ai_provider/src/Exception/ProviderUnavailableException.php
```

All should return `No syntax errors detected`.

## Done

Move to `04_GROK_PROVIDER.md`.
