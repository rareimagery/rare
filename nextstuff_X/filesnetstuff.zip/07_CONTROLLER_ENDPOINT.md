# Step 7 — Controller & Endpoint

## What This Does

Creates the Drupal controller that exposes `/jsonapi/ai-provider/generate` as a POST endpoint. This is what the Next.js API route proxies to. It accepts a JSON body, dispatches through the `AiProviderManager`, and returns the normalized response.

## AiGenerateController.php

**File:** `src/Controller/AiGenerateController.php`

```php
<?php

namespace Drupal\ai_provider\Controller;

use Drupal\ai_provider\AiProviderManager;
use Drupal\ai_provider\Exception\AiGenerationException;
use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

/**
 * Handles AI generation requests from the Next.js frontend.
 */
class AiGenerateController extends ControllerBase {

  public function __construct(
    private AiProviderManager $aiManager,
  ) {}

  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('ai_provider.manager'),
    );
  }

  /**
   * POST /jsonapi/ai-provider/generate
   *
   * Expected JSON body:
   * {
   *   "task_type": "page_builder",
   *   "prompt_data": {
   *     "user_input": "Create a hero section with my latest products",
   *     "subculture": "emo",
   *     "existing_theme": "{ ... }"
   *   },
   *   "options": {
   *     "temperature": 1,
   *     "max_tokens": 20000
   *   }
   * }
   */
  public function generate(Request $request): JsonResponse {
    // --- Parse request body ---
    $body = json_decode($request->getContent(), TRUE);

    if (json_last_error() !== JSON_ERROR_NONE) {
      return new JsonResponse([
        'error' => 'Invalid JSON in request body.',
      ], 400);
    }

    $task_type = $body['task_type'] ?? NULL;
    $prompt_data = $body['prompt_data'] ?? [];
    $options = $body['options'] ?? [];

    // --- Validate task type ---
    $allowed_tasks = [
      'page_builder',
      'theme_generation',
      'profile_import',
      'content_generation',
    ];

    if (!$task_type || !in_array($task_type, $allowed_tasks, TRUE)) {
      return new JsonResponse([
        'error' => 'Invalid or missing task_type.',
        'allowed' => $allowed_tasks,
      ], 400);
    }

    // --- Validate prompt data ---
    if (empty($prompt_data['user_input'])) {
      return new JsonResponse([
        'error' => 'prompt_data.user_input is required.',
      ], 400);
    }

    // --- Dispatch ---
    try {
      $response = $this->aiManager->dispatch($task_type, $prompt_data, $options);

      return new JsonResponse([
        'status' => 'ok',
        'result' => $response->toArray(),
      ]);
    }
    catch (AiGenerationException $e) {
      $this->getLogger('ai_provider')->error('Generation failed: @msg', [
        '@msg' => $e->getMessage(),
      ]);

      return new JsonResponse([
        'error' => 'AI generation failed. Please try again.',
        'detail' => $e->getMessage(),
      ], 502);
    }
    catch (\Throwable $e) {
      $this->getLogger('ai_provider')->error('Unexpected error: @msg', [
        '@msg' => $e->getMessage(),
      ]);

      return new JsonResponse([
        'error' => 'Internal server error.',
      ], 500);
    }
  }

}
```

## Next.js Proxy (Reference)

Your existing Next.js API route that proxies to Drupal. Minimal change — just point it at the new endpoint if it isn't already:

**File:** `app/api/ai/generate/route.ts` (Next.js App Router)

```typescript
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';

export async function POST(request: NextRequest) {
  // Auth check — creator must be logged in.
  const session = await getServerSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const body = await request.json();

  const drupalUrl = process.env.DRUPAL_BASE_URL + '/jsonapi/ai-provider/generate';

  const response = await fetch(drupalUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      // Pass session cookie or service account auth to Drupal.
      'Authorization': `Bearer ${process.env.DRUPAL_API_TOKEN}`,
    },
    body: JSON.stringify(body),
  });

  const data = await response.json();
  return NextResponse.json(data, { status: response.status });
}
```

## Enable the Module

All PHP files are now in place. Enable the module:

```bash
cd /path/to/drupal
drush en ai_provider -y
drush cr
```

If you get class-not-found errors, clear the Composer autoload cache:

```bash
composer dump-autoload
drush cr
```

## Verify the Endpoint Exists

```bash
drush route:list | grep ai-provider
```

Should output:

```
ai_provider.generate  POST  /jsonapi/ai-provider/generate
```

## Done

Move to `08_VERIFY.md`.
