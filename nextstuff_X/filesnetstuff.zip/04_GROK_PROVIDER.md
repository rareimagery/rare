# Step 4 — Grok Provider

## What This Does

Wraps your existing Grok (xAI) API calls in the new `AiProviderInterface`. This is mostly a refactor — your current Grok logic moves into this class. The actual prompts and API call patterns stay the same.

## GrokProvider.php

**File:** `src/Provider/GrokProvider.php`

```php
<?php

namespace Drupal\ai_provider\Provider;

use Drupal\ai_provider\Model\AiResponse;
use Drupal\ai_provider\Exception\AiGenerationException;
use GuzzleHttp\ClientInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;

/**
 * xAI Grok provider — primary for all tasks.
 */
class GrokProvider implements AiProviderInterface {

  private const API_URL = 'https://api.x.ai/v1/chat/completions';

  private $logger;

  public function __construct(
    private ClientInterface $httpClient,
    LoggerChannelFactoryInterface $loggerFactory,
  ) {
    $this->logger = $loggerFactory->get('ai_provider');
  }

  public function getKey(): string {
    return 'grok';
  }

  public function isAvailable(): bool {
    return !empty($this->getApiKey());
  }

  public function generate(string $task_type, array $prompt_data, array $options = []): AiResponse {
    $system_prompt = $this->buildSystemPrompt($task_type, $prompt_data);
    $user_message = $prompt_data['user_input'] ?? '';

    $payload = [
      'model' => getenv('GROK_MODEL') ?: 'grok-3',
      'messages' => [
        ['role' => 'system', 'content' => $system_prompt],
        ['role' => 'user', 'content' => $user_message],
      ],
      'temperature' => $options['temperature'] ?? 1,
      'max_tokens' => $options['max_tokens'] ?? 4096,
    ];

    try {
      $response = $this->httpClient->request('POST', self::API_URL, [
        'headers' => [
          'Authorization' => 'Bearer ' . $this->getApiKey(),
          'Content-Type' => 'application/json',
        ],
        'json' => $payload,
        'timeout' => 60,
      ]);

      $data = json_decode($response->getBody()->getContents(), TRUE);
      return $this->normalizeResponse($data, $task_type);
    }
    catch (\Throwable $e) {
      $this->logger->error('Grok generation failed: @message', ['@message' => $e->getMessage()]);
      throw new AiGenerationException('Grok generation failed: ' . $e->getMessage(), 0, $e);
    }
  }

  private function normalizeResponse(array $data, string $task_type): AiResponse {
    $text = $data['choices'][0]['message']['content'] ?? '';

    // For structured tasks, attempt JSON parse.
    $structured = NULL;
    if (in_array($task_type, ['page_builder', 'theme_generation'], TRUE)) {
      $decoded = json_decode($text, TRUE);
      if (json_last_error() === JSON_ERROR_NONE) {
        $structured = $decoded;
      }
      else {
        throw new AiGenerationException('Grok returned invalid JSON for ' . $task_type);
      }
    }

    return new AiResponse(
      provider: 'grok',
      task_type: $task_type,
      raw_text: $text,
      structured_data: $structured,
      model: $data['model'] ?? '',
      usage: $data['usage'] ?? [],
    );
  }

  private function getApiKey(): string {
    return getenv('XAI_API_KEY') ?: '';
  }

  /**
   * Build system prompt per task type.
   *
   * IMPORTANT: Port your existing Grok system prompts here.
   * The examples below are placeholders — replace with your actual
   * prompts from the current implementation.
   */
  private function buildSystemPrompt(string $task_type, array $prompt_data): string {
    return match ($task_type) {
      'page_builder' => $this->getPageBuilderPrompt($prompt_data),
      'theme_generation' => $this->getThemeGenerationPrompt($prompt_data),
      'profile_import' => $this->getProfileImportPrompt($prompt_data),
      'content_generation' => $this->getContentGenerationPrompt($prompt_data),
      default => 'You are a helpful assistant for RareImagery.',
    };
  }

  // ------------------------------------------------------------------
  // PORT YOUR EXISTING GROK PROMPTS INTO THESE METHODS.
  // These are stubs — fill in with your actual prompt logic.
  // ------------------------------------------------------------------

  private function getPageBuilderPrompt(array $prompt_data): string {
    // TODO: Port existing page builder system prompt.
    return 'You are the RareImagery Page Builder AI. Output ONLY valid JSON.';
  }

  private function getThemeGenerationPrompt(array $prompt_data): string {
    // TODO: Port from MYSPACE_THEME_BOT_RULES.md prompts.
    return 'You are the RareImagery Theme Bot. Output ONLY valid JSON theme config.';
  }

  private function getProfileImportPrompt(array $prompt_data): string {
    // TODO: Port existing X profile import prompt.
    return 'You are the RareImagery Profile Import assistant.';
  }

  private function getContentGenerationPrompt(array $prompt_data): string {
    // TODO: Port if exists, or create new.
    return 'You are a content assistant for RareImagery creator storefronts.';
  }

}
```

## Migration Notes

This is the one step that requires porting existing code. Wherever you currently call the Grok API directly:

1. Move the system prompt logic into the corresponding `get*Prompt()` method.
2. Move any response parsing logic into `normalizeResponse()`.
3. Update callers to go through `AiProviderManager::dispatch()` instead of calling Grok directly. (That wiring happens in Steps 6–7.)

If your existing Grok calls are scattered across multiple modules, you can do this incrementally — leave the old calls in place, get the new module working end-to-end for `page_builder` first, then migrate the remaining task types one at a time.

## Verify

```bash
php -l modules/custom/ai_provider/src/Provider/GrokProvider.php
```

## Done

Move to `05_CLAUDE_PROVIDER.md`.
