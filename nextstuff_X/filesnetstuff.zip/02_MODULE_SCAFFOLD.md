# Step 2 — Module Scaffold

## What This Does

Creates the Drupal custom module directory structure and the three YAML config files that register it with Drupal.

## Directory Structure

Create this under your Drupal installation:

```
modules/custom/ai_provider/
├── ai_provider.info.yml
├── ai_provider.services.yml
├── ai_provider.routing.yml
├── src/
│   ├── AiProviderManager.php
│   ├── Provider/
│   │   ├── AiProviderInterface.php
│   │   ├── GrokProvider.php
│   │   └── ClaudeProvider.php
│   ├── Model/
│   │   └── AiResponse.php
│   ├── Controller/
│   │   └── AiGenerateController.php
│   └── Exception/
│       ├── ProviderUnavailableException.php
│       └── AiGenerationException.php
```

Create the directories first:

```bash
cd /path/to/drupal
mkdir -p modules/custom/ai_provider/src/{Provider,Model,Controller,Exception}
```

## ai_provider.info.yml

```yaml
name: 'AI Provider'
type: module
description: 'Multi-provider AI abstraction layer. Routes requests to Grok (primary) or Claude (fallback).'
core_version_requirement: ^10
package: 'RareImagery'
dependencies:
  - drupal:jsonapi
```

## ai_provider.services.yml

```yaml
services:
  ai_provider.grok:
    class: Drupal\ai_provider\Provider\GrokProvider
    arguments: ['@http_client', '@logger.factory']

  ai_provider.claude:
    class: Drupal\ai_provider\Provider\ClaudeProvider
    arguments: ['@http_client', '@logger.factory']

  ai_provider.manager:
    class: Drupal\ai_provider\AiProviderManager
    arguments:
      - '@ai_provider.grok'
      - '@ai_provider.claude'
      - '@logger.factory'
```

## ai_provider.routing.yml

```yaml
ai_provider.generate:
  path: '/jsonapi/ai-provider/generate'
  defaults:
    _controller: '\Drupal\ai_provider\Controller\AiGenerateController::generate'
  methods: [POST]
  requirements:
    _permission: 'access content'
  options:
    _auth: ['cookie', 'oauth2']
    no_cache: TRUE
```

## Verify

```bash
# Check the structure looks right
find modules/custom/ai_provider -type f | sort
```

You should see the three YAML files. The `src/` directories are empty — that's fine, the PHP classes come in the next steps.

Do NOT enable the module yet. Wait until all PHP files are in place (after Step 7).

## Done

Move to `03_PROVIDER_INTERFACE.md`.
