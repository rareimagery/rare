# Step 8 — Verify

## What This Does

Smoke tests to confirm the module is working end-to-end. Run these after completing Steps 1–7 and enabling the module.

---

## 1. Module Status

```bash
drush pm:list --status=enabled | grep ai_provider
```

Expected: `ai_provider` shows as enabled.

---

## 2. Route Registration

```bash
drush route:list | grep ai-provider
```

Expected: `ai_provider.generate  POST  /jsonapi/ai-provider/generate`

---

## 3. Test Claude Directly (CLI)

Verify the Anthropic API key works before testing through Drupal:

```bash
curl -s https://api.anthropic.com/v1/messages \
  -H "x-api-key: $ANTHROPIC_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d '{
    "model": "claude-sonnet-4-6",
    "max_tokens": 256,
    "thinking": {"type": "disabled"},
    "messages": [
      {"role": "user", "content": "Reply with exactly: {\"status\": \"ok\"}"}
    ]
  }'
```

Expected: A JSON response with `content[0].text` containing `{"status": "ok"}`.

If this fails, check:
- API key is correct and active
- VPS can reach `api.anthropic.com` (no firewall blocking outbound HTTPS)

---

## 4. Test Drupal Endpoint — Happy Path

```bash
curl -s -X POST http://localhost/jsonapi/ai-provider/generate \
  -H "Content-Type: application/json" \
  -d '{
    "task_type": "page_builder",
    "prompt_data": {
      "user_input": "Create a simple hero section with a welcome message",
      "subculture": "emo"
    }
  }'
```

Expected response:

```json
{
  "status": "ok",
  "result": {
    "provider": "grok",
    "task_type": "page_builder",
    "data": { "components": [...], "metadata": {...} },
    "meta": { "model": "grok-3", "usage": {...} }
  }
}
```

The `provider` field tells you which model handled the request. Should be `grok` (primary).

---

## 5. Test Failover

Temporarily break Grok to verify Claude takes over. Set an invalid Grok key:

```bash
# Save the real key first
REAL_GROK_KEY=$XAI_API_KEY

# Set invalid key
export XAI_API_KEY=invalid-key-for-testing

# Restart PHP-FPM to pick up the env change
sudo systemctl restart php-fpm

# Run the same request
curl -s -X POST http://localhost/jsonapi/ai-provider/generate \
  -H "Content-Type: application/json" \
  -d '{
    "task_type": "page_builder",
    "prompt_data": {
      "user_input": "Create a simple hero section",
      "subculture": "default"
    }
  }'
```

Expected: Response with `"provider": "claude"` — failover worked.

Check Drupal logs for the failover warning:

```bash
drush watchdog:show --type=ai_provider --count=5
```

Should show a `warning` entry like: `AI failover: page_builder — grok failed (...), trying claude`

**Restore the real key when done:**

```bash
export XAI_API_KEY=$REAL_GROK_KEY
sudo systemctl restart php-fpm
```

---

## 6. Test Validation Errors

**Missing task_type:**

```bash
curl -s -X POST http://localhost/jsonapi/ai-provider/generate \
  -H "Content-Type: application/json" \
  -d '{"prompt_data": {"user_input": "test"}}'
```

Expected: `400` with `"error": "Invalid or missing task_type."`

**Missing user_input:**

```bash
curl -s -X POST http://localhost/jsonapi/ai-provider/generate \
  -H "Content-Type: application/json" \
  -d '{"task_type": "page_builder", "prompt_data": {}}'
```

Expected: `400` with `"error": "prompt_data.user_input is required."`

**Invalid JSON body:**

```bash
curl -s -X POST http://localhost/jsonapi/ai-provider/generate \
  -H "Content-Type: application/json" \
  -d 'not json'
```

Expected: `400` with `"error": "Invalid JSON in request body."`

---

## 7. Test from Next.js (End-to-End)

If your Next.js dev server is running:

```bash
curl -s -X POST http://localhost:3000/api/ai/generate \
  -H "Content-Type: application/json" \
  -b "session_cookie=your_session_here" \
  -d '{
    "task_type": "page_builder",
    "prompt_data": {
      "user_input": "Create a product grid with 3 columns",
      "subculture": "scene_kid"
    }
  }'
```

This tests the full chain: Next.js → Drupal → Provider → Response.

---

## Checklist

| # | Test | Status |
|---|------|--------|
| 1 | Module enabled | ☐ |
| 2 | Route registered | ☐ |
| 3 | Claude API key works (direct curl) | ☐ |
| 4 | Drupal endpoint returns Grok response | ☐ |
| 5 | Failover to Claude works | ☐ |
| 6 | Validation errors return 400 | ☐ |
| 7 | Next.js proxy end-to-end works | ☐ |

Once all boxes are checked, the module is production-ready. The existing `FloatingBuilder.tsx` should work without any changes — it's already hitting the endpoint that now routes through `AiProviderManager`.
